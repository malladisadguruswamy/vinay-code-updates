<?php
include 'config.php';
$action = $_GET['action'];
//echo '<pre>'; print_r($_POST); exit();
if($action == 'insert'){
	$fname =  $_POST["fname"];
	$lname =  $_POST["lname"];
	$email =  $_POST["email"];
	$mobile = $_POST["mobile"];
	$email  =  $_POST["email"];
	$membership_plan =       $_POST["membership_plan"];
	$membership_plan_cost =  $_POST["membership_plan_cost"];
	$extra_amount =  $_POST["extra_amount"];
	$total =  $_POST["grand_total"];
	$street =  $_POST["street"];
	$city =    $_POST["city"];
	$state =   $_POST["state"];
	$country =   $_POST["country"];
	$password =$_POST["pwd"];
	$sfname =  $_POST["sfname"];
	$slname =  $_POST["slname"];
	$name_coumns = '';
	$age_coumns = '';
	$name_values = '';
	$age_values = '';
	$name_data = '';
	$age_data = '';
	if(isset($_POST['Child_name'])){
		foreach ($_POST['Child_name'] as $key => $value) {
			$i = $key+1;
			if($i ==3){
				continue;
			}
			$name_coumns.= ',child_name_'.$i; 
			$age_coumns.= ',child_age_'.$i;
			$name_values.= ",'".$_POST['Child_name'][$key]."'";
			$age_values.=",'".$_POST['Child_age'][$key]."'";
			$name_data.= ",child_name_".$i. " = "."'".$_POST['Child_name'][$key]."'"; 
			$age_data.= ",child_age_".$i. " = "."'".$_POST['Child_age'][$key]."'"; 
		}
	}else{
		$name_coumns = '';$name_values = '';
		$age_coumns = '';$age_values = '';
		$name_data = '';$age_data = '';
	}
	$sql = "SELECT user_id FROM tata_users WHERE email_id = '".$email."' ";
	$result = mysqli_query($conn, $sql);
	// Email already exist ;
	if (mysqli_num_rows($result) > 0) {
		// email Exist so update here
		$id = '';
			// print_r($_POST); exit();
			if(!empty($result)){
				while ($row = mysqli_fetch_assoc($result)) {
					$id = $row['user_id'];
				}
			}
		$sql = "UPDATE tata_users SET first_name ='$fname',last_name='$lname',  mobile_number='$mobile',membership_plan_name='$membership_plan',membership_price='$membership_plan_cost',password='$password',street='$street',city='$city',state='$state',country='$country',spouse_first_name='$sfname',spouse_last_name='$slname',extra_amount ='$extra_amount',total ='$total' ".$name_data." ".$age_data." where user_id='$id' ";
		if(mysqli_query($conn, $sql)) {
			echo json_encode(array('uid' =>  $id ,'status' => 'success' ,'msg' => 'New record updated successfully' ));
		}
	}else{
		$sql = "INSERT INTO tata_users (first_name, last_name, email_id, mobile_number,membership_plan_name,membership_price,password,street,city,state,country,spouse_first_name,spouse_last_name,status ".$name_coumns." ".$age_coumns." ,extra_amount,total)
		VALUES ('$fname', '$lname', '$email','$mobile', '$membership_plan', '$membership_plan_cost','$password','$street', '$city', '$state','$country', '$sfname', '$slname','0' ".$name_values." ".$age_values. " ,'$extra_amount','$total')";
		// echo $sql; exit();
		if (mysqli_query($conn, $sql)) {
		  $tata_user = mysqli_insert_id($conn);
		  echo json_encode(array('uid' =>  $tata_user ,'status' => 'success' ,'msg' => 'New record created successfully' ));
		} else {
		  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
	}
}elseif($action == 'update'){
	// Update record
	$id =  $_POST["user_id"];
	$email = $_POST['email'];
	$sql = "SELECT user_id FROM tata_users WHERE email_id = '".$email."' and verify_status = 1 and user_id != '".$id."'";
	$result = mysqli_query($conn, $sql);
	// Email already exist ;
	if (mysqli_num_rows($result) > 0) {
		echo json_encode(array('status' => 'existed' ,'msg' => 'Email already existed with other account' ));
	}else{
		$fname =  $_POST["user_fname"];
		$lname =  $_POST["user_lname"];
		$email =  $_POST["user_email"];
		$mobile = $_POST["user_mobile"];
		$email  =  $_POST["user_email"];
		$membership_plan =       $_POST["membership_plan"];
		$membership_plan_cost =  $_POST["membership_plan_cost"];
		$extra_amount =  $_POST["final_extra_amount"];
		$total =  $_POST["grand_total"];
		$street =  $_POST["user_street"];
		$city =    $_POST["user_city"];
		$state =   $_POST["user_state"];
		$country =   $_POST["user_country"];
		$password =$_POST["user_pwd"];
		$sfname =  $_POST["user_sfname"];
		$slname =  $_POST["user_slname"];
		
		$sql = "UPDATE tata_users SET first_name ='$fname',last_name='$lname', email_id='$email', mobile_number='$mobile',membership_plan_name='$membership_plan',membership_price='$membership_plan_cost',password='$password',street='$street',city='$city',state='$state',country='$country',spouse_first_name='$sfname',spouse_last_name='$slname',extra_amount ='$extra_amount',total ='$total' where user_id='$id' ";
		if (mysqli_query($conn, $sql)) {
			$x_login = "WSP-TELAN-o5DbNADVzw"; // Take from Payment Page ID in Payment Pages interface
			$transaction_key = "pkstd68C5nYQ0QZmb20h"; // Take from Payment Pages configuration interface
			$x_currency_code = "USD"; // Needs to agree with the currency of the payment page
			srand(time()); // initialize random generator for x_fp_sequence
			$x_amount = $total;
			$x_fp_sequence = rand(1000, 100000) + 123656;
			$x_fp_timestamp = time();
			$hmac_data = $x_login . "^" . $x_fp_sequence . "^" . $x_fp_timestamp . "^" . $x_amount . "^" . $x_currency_code;
			$x_fp_hash = hash_hmac('MD5', $hmac_data, $transaction_key);
			$payeezy = 	array( 
							'x_login' => $x_login,
							'transaction_key' => $transaction_key,
							'x_currency_code' => $x_currency_code,
							'x_amount' => $x_amount,
							'x_fp_sequence' => $x_fp_sequence,
							'x_fp_timestamp' => $x_fp_timestamp,
							'hmac_data' => $hmac_data,
							'x_fp_hash' => $x_fp_hash
						);
		    echo json_encode(array('uid' =>  $id ,'status' => 'success' ,'msg' => 'Record updated successfully', 'payeezy' => $payeezy));
		} else {
		    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
	}
}elseif($action == 'email_check'){
	$email = $_POST['email'];
	$sql = "SELECT user_id FROM tata_users WHERE email_id = '".$email."' ";
	$result = mysqli_query($conn, $sql);
	// Email already exist ;
	if (mysqli_num_rows($result) > 0) {
		$check = "SELECT user_id FROM tata_users WHERE email_id = '".$email."' and verify_status = 1";
		$check_result = mysqli_query($conn, $check);
		if (mysqli_num_rows($check_result) > 0) {
			// restrict with email here
			echo json_encode(array('status' => 'existed' ,'msg' => 'Email already existed with other account' ));
		}else{
			// Need to update & proced to Next Step
			$id = '';
			// print_r($_POST); exit();
			if(!empty($check_result)){
				while ($row = mysqli_fetch_assoc($check_result)) {
					$id = $row['user_id'];
				}
			}
			$fname =  $_POST["fname"];
			$lname =  $_POST["lname"];
			$email =  $_POST["email"];
			$mobile = $_POST["mobile"];
			$email  =  $_POST["email"];
			$membership_plan =       $_POST["membership_plan"];
			$membership_plan_cost =  $_POST["membership_plan_cost"];
			$extra_amount =  $_POST["extra_amount"];
			$total =  $_POST["grand_total"];
			$street =  $_POST["street"];
			$city =    $_POST["city"];
			$state =   $_POST["state"];
			$country =   $_POST["country"];
			$password =$_POST["pwd"];
			$sfname =  $_POST["sfname"];
			$slname =  $_POST["slname"];
			$name_data = '';
			$age_data = '';
			if(isset($_POST['Child_name'])){
				foreach ($_POST['Child_name'] as $key => $value) {
					$i = $key+1;
					if($i ==3){
						continue;
					}
					$name_data.= ",child_name_".$i. " = "."'".$_POST['Child_name'][$key]."'"; 
					$age_data.= ",child_age_".$i. " = "."'".$_POST['Child_age'][$key]."'"; 
				}
			}else{
				$name_data = '';
				$age_data = '';
			} // child if close
			//
			$sql = "UPDATE tata_users SET first_name ='$fname',last_name='$lname',  mobile_number='$mobile',membership_plan_name='$membership_plan',membership_price='$membership_plan_cost',password='$password',street='$street',city='$city',state='$state',country='$country',spouse_first_name='$sfname',spouse_last_name='$slname',extra_amount ='$extra_amount',total ='$total' ".$name_data." ".$age_data." where user_id='$id' ";
			if(mysqli_query($conn, $sql)) {
				echo json_encode(array('uid' =>  $id ,'status' => 'success' ,'msg' => 'New record updated successfully' ));
			}
		}
	} else {
		// New user
	  	echo json_encode(array('status' => 'proceed' ,'msg' => 'New record created successfully' ));
	}
	// print_r($_POST); exit();
}


mysqli_close($conn);
?>
